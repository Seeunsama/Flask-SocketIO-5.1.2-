API Reference
=============

.. module:: flask_socketio
.. autoclass:: SocketIO
   :members:
.. autofunction:: emit
.. autofunction:: send
.. autofunction:: join_room
.. autofunction:: leave_room
.. autofunction:: close_room
.. autofunction:: rooms
.. autofunction:: disconnect
.. autoclass:: Namespace
   :members:
.. autoclass:: SocketIOTestClient
   :members:
